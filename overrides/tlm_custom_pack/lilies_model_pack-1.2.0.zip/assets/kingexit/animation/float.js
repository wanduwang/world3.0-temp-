var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw,
        headPitch, scale, modelMap) {
        head = modelMap.get("head")
        hair = modelMap.get("hair")
        body = modelMap.get("body")
        armLeft = modelMap.get("armLeft")
        armRight = modelMap.get("armRight")
        legLeft = modelMap.get("legLeft")
        legRight = modelMap.get("legRight")
        legLeftInner = modelMap.get("legLeftInner")
        legRightInner = modelMap.get("legRightInner")
        sittingRotationSkirt = modelMap.get("sittingRotationSkirt")
        wing = modelMap.get("wing")

        if (maid.isSleep()) {
            head.setRotateAngleX(head.getInitRotateAngleX())
            head.setOffsetY(0)
            head.setOffsetZ(0)

            hair.setRotateAngleX(hair.getInitRotateAngleX())
            hair.setOffsetY(0)

            body.setRotateAngleX(0)
            body.setOffsetY(0)
            body.setOffsetZ(0)

            sittingRotationSkirt.setRotateAngleX(sittingRotationSkirt.getInitRotateAngleX())

            wing.setRotateAngleX(wing.getInitRotateAngleX())
            wing.setOffsetY(0)
            wing.setOffsetZ(0)

            armLeft.setRotateAngleX(armLeft.getInitRotateAngleX())
            armLeft.setRotateAngleY(armLeft.getInitRotateAngleY())
            armLeft.setRotateAngleZ(armLeft.getInitRotateAngleZ())
            armLeft.setOffsetX(0)
            armLeft.setOffsetZ(0)

            armRight.setRotateAngleX(armRight.getInitRotateAngleX())
            armRight.setRotateAngleY(armRight.getInitRotateAngleY())
            armRight.setRotateAngleZ(armRight.getInitRotateAngleZ())
            armRight.setOffsetX(0)
            armRight.setOffsetZ(0)

            legLeft.setRotateAngleX(legLeft.getInitRotateAngleX())
            legLeft.setRotateAngleY(legLeft.getInitRotateAngleY())
            legLeft.setRotateAngleZ(legLeft.getInitRotateAngleZ())
            legLeft.setOffsetY(0)
            legLeft.setOffsetZ(0)

            legLeftInner.setRotateAngleX(legLeftInner.getInitRotateAngleX())
            legLeftInner.setOffsetY(0)

            legRight.setRotateAngleX(legRight.getInitRotateAngleX())
            legRight.setRotateAngleY(legRight.getInitRotateAngleY())
            legRight.setRotateAngleZ(legRight.getInitRotateAngleZ())
            legRight.setOffsetY(0)
            legRight.setOffsetZ(0)

            legRightInner.setRotateAngleX(legRightInner.getInitRotateAngleX())
            legRightInner.setOffsetY(0)

            GlWrapper.translate(0, 0.15, 0)
        }

        else if (maid.isSitting()) {
            head.setRotateAngleX(head.getInitRotateAngleX())
            head.setOffsetY(0.015625)
            head.setOffsetZ(-0.109375)

            hair.setRotateAngleX(hair.getInitRotateAngleX())
            hair.setOffsetY(0)

            body.setRotateAngleX(0.17)
            body.setOffsetY(0)
            body.setOffsetZ(0)

            sittingRotationSkirt.setRotateAngleX(-0.22)

            wing.setRotateAngleX(wing.getInitRotateAngleX())
            wing.setOffsetY(0)
            wing.setOffsetZ(0)

            armLeft.setRotateAngleX(armLeft.getInitRotateAngleX() - 0.39)
            armLeft.setRotateAngleY(armLeft.getInitRotateAngleY() + 0.05)
            armLeft.setRotateAngleZ(armLeft.getInitRotateAngleZ() + 0.61)
            armLeft.setOffsetX(-0.046875)
            armLeft.setOffsetZ(-0.125)

            armRight.setRotateAngleX(armRight.getInitRotateAngleX() - 0.39)
            armRight.setRotateAngleY(armRight.getInitRotateAngleY() - 0.05)
            armRight.setRotateAngleZ(armRight.getInitRotateAngleZ() - 0.61)
            armRight.setOffsetX(0.046875)
            armRight.setOffsetZ(-0.125)

            legLeft.setRotateAngleX(-1.38)
            legLeft.setRotateAngleY(-0.38)
            legLeft.setRotateAngleZ(-0.07)
            legLeft.setOffsetY(0)
            legLeft.setOffsetZ(-0.13125)

            legLeftInner.setRotateAngleX(legLeftInner.getInitRotateAngleX())
            legLeftInner.setOffsetY(0)

            legRight.setRotateAngleX(-1.38)
            legRight.setRotateAngleY(0.38)
            legRight.setRotateAngleZ(0.07)
            legRight.setOffsetY(0)
            legRight.setOffsetZ(-0.13125)

            legRightInner.setRotateAngleX(legRightInner.getInitRotateAngleX())
            legRightInner.setOffsetY(0)

            GlWrapper.translate(0, 0.1 * Math.sin(ageInTicks * 0.075) - 0.1, 0)
        }

        else {
            head.setRotateAngleX(0.04)
            head.setOffsetY(0.03125)
            head.setOffsetZ(0.03125)

            hair.setRotateAngleX(hair.getInitRotateAngleX() + 0.47)
            hair.setOffsetY(-0.0625)

            body.setRotateAngleX(0.92)
            body.setOffsetY(-0.1875)
            body.setOffsetZ(0.34375)

            sittingRotationSkirt.setRotateAngleX(-0.13)

            wing.setRotateAngleX(wing.getInitRotateAngleX() - 0.39)
            wing.setOffsetY(0.1625)
            wing.setOffsetZ(-0.1875)

            armLeft.setRotateAngleX(armLeft.getInitRotateAngleX())
            armLeft.setRotateAngleY(armLeft.getInitRotateAngleY())
            armLeft.setRotateAngleZ(armLeft.getInitRotateAngleZ())
            armLeft.setOffsetX(0)
            armLeft.setOffsetZ(0)

            armRight.setRotateAngleX(armRight.getInitRotateAngleX())
            armRight.setRotateAngleY(armRight.getInitRotateAngleY())
            armRight.setRotateAngleZ(armRight.getInitRotateAngleZ())
            armRight.setOffsetX(0)
            armRight.setOffsetZ(0)

            legLeft.setRotateAngleX(0.26)
            legLeft.setRotateAngleY(legLeft.getInitRotateAngleY())
            legLeft.setRotateAngleZ(legLeft.getInitRotateAngleZ())
            legLeft.setOffsetY(-0.3125)
            legLeft.setOffsetZ(0.40625)

            legLeftInner.setRotateAngleX(1.53)
            legLeftInner.setOffsetY(0.125)

            legRight.setRotateAngleX(0.26)
            legRight.setRotateAngleY(legRight.getInitRotateAngleY())
            legRight.setRotateAngleZ(legRight.getInitRotateAngleZ())
            legRight.setOffsetY(-0.3125)
            legRight.setOffsetZ(0.40625)

            legRightInner.setRotateAngleX(1.53)
            legRightInner.setOffsetY(0.125)

            GlWrapper.translate(0, 0.1 * Math.sin(ageInTicks * 0.075) - 0.1, 0)
        }
    }
})