var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
	animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
		blinkDownA = modelMap.get("blikdownA");        // 眼睫毛
		blinkDownB = modelMap.get("blikdownB");        // 上眼皮
		blinkUp = modelMap.get("blikup");              // 下眼皮
		
		if ((blinkDownA != undefined) && (blinkDownB != undefined) && (blinkUp != undefined)) {
			remainder = (ageInTicks + Math.abs(maid.getSeed()) % 10) % 60;
			isBlinkTime = 55 < remainder && remainder < 60;
			if (maid.isSleep()) {
				blinkDownA.setOffsetY(0.0625);
				blinkDownB.setOffsetY(0.0625);
				blinkUp.setOffsetY(-0.0625);
				// 睡觉时略微移动点距离
				GlWrapper.translate(0, -0.1406, 0)
			} else if (isBlinkTime) {
				blinkDownA.setOffsetY(0.078125);
				blinkDownB.setOffsetY(0.0625);
				blinkUp.setOffsetY(-0.0625);
			} else {
				blinkDownA.setOffsetY(0);
				blinkDownB.setOffsetY(0);
				blinkUp.setOffsetY(0);
			}
		}
		//以上内容是酒石酸大大修改过的，虽然可以正常运行但是眨眼是瞬间完成的
		/*故障的函数，暂时注释掉
        if ((blikdownA != undefined) && (blikdownB != undefined) && (blikup != undefined)) {
            remainder = ageInTicks % 60;
            if (maid.isSleep()) {
				blinkDownA.setOffsetY(0.078125);
				blinkDownB.setOffsetY(0.0625);
				blinkUp.setOffsetY(-0.0625);
				//高度数据为闭眼
				GlWrapper.translate(0, 0.2, 0);
				//提高女仆的高度
			} else if (!(115 < remainder && remainder < 120)) {
				blikmY = Math.abs(Math.cos(((remainder - 115) / 5 * 3.141592692)));
				//将remainder处理为0~1的绝对值cos函数
				blikdownA.setOffsetY((0 - blikmY) * 1.25);
				blikdownB.setOffsetY(0 - blikmY);
				blikup.setOffsetY(blikmY);
				//最终处理为高度数据
			} else {
				blikdownAY = blikdownA.getOffsetY();
				blikdownBY = blikdownB.getOffsetY();
				blikupY = blikup.getOffsetY();
				//获取初始高度数据
			}
        }
		*/
    }
})