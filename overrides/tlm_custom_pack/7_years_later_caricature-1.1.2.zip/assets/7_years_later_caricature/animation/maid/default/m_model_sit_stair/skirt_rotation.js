Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
        sittingRotationSkirt = modelMap.get("sittingRotationSkirt");
        if (sittingRotationSkirt != undefined) {
            if (maid.isRidingMarisaBroom() || maid.isRiding()) {
                sittingRotationSkirt.setRotateAngleX(-1.128);
            } else if (maid.isSitting()) {
                sittingRotationSkirt.setRotateAngleX(-1.308);
            } else {
                sittingRotationSkirt.setRotateAngleX(0);
            }
        }
    }
})