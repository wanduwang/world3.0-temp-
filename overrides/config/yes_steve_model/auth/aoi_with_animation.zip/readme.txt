模型由vanli233制作，动画基于YSM深度修改。
本模型和动画遵循CC 0协议，可任意修改或使用，但不可用于违反中国法律的用途。
由于一些原因，头的组名首字母需要大写，其余的组名首字母请不要大写。
本包未来可能会维护。

以下是有动画功能的组的列表及其父子关系：
root:根
	Head:头
	body:身体
		sittingRotationSkirt:裙子
	armLeft:左臂
		forearmLeft:左小臂
			handLeft:左手
	armRight:右臂
		forearmRight:右小臂
			handRight:右手
	legLeft:左腿
		shinLeft:左小腿
			footLeft:左脚
	legRight:左腿
		shinRight:左小腿
			footRight:左脚