var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
        //毁灭菇动画
        doom_shroom = modelMap.get("doom_shroom");
        var i = -Math.exp(Math.sin(ageInTicks * 0.01) * 1.5 - 3) + 1.2;

        GlWrapper.scale(i, i, i);
        GlWrapper.translate(0,-i * 1.11 + 1.1,0);
    }
})