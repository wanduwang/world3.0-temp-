var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
        springFestival = modelMap.get("spring_festival");
        christmas = modelMap.get("christmas");
        resourcepackAnniversary = modelMap.get("resourcepack_anniversary");
        plantsVsZombiesAnniversary = modelMap.get("plants_vs_zombies_anniversary");
        halloween = modelMap.get("halloween");

        date = new Date();
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var day = date.getDate();

        //女仆不会因为坐下改变位置
        if (maid.isSitting()) {
            GlWrapper.translate(0, 0, 0);
        }

        //特殊日期装饰一般都是提前两天开始,持续五天
        //圣诞 12月23日 ~ 12月27日
        if (christmas != undefined) {
            if (month == 12 && day >= 23 && day <= 27) {
                christmas.setHidden(false);
            } else {
                christmas.setHidden(true);
            }
        }

        //春节
        if (springFestival != undefined) {
            if(year == 2022 && month == 2 && day >= 1 && day <= 4) {
                springFestival.setHidden(false);
            } else if (year == 2023 && month == 1 && day >= 20 && day <= 24) {
                springFestival.setHidden(false);
            } else if (year == 2024 && month == 2 && day >= 7 && day <= 12) {
                springFestival.setHidden(false);
            } else {
                springFestival.setHidden(true);
            }
        }

        //这个资源包的周年庆
        //日期 3月7日 ~ 3月11日
        if (resourcepackAnniversary != undefined) {
            if (month == 3 && day >= 7 && day <= 11) {
                resourcepackAnniversary.setHidden(false);
            } else {
                resourcepackAnniversary.setHidden(true);
            }
        }

        //植物大战僵尸周年庆
        //日期 5月3日 ~ 5月7日
        if (plantsVsZombiesAnniversary != undefined) {
            if (month == 5 && day >= 3 && day <= 7) {
                plantsVsZombiesAnniversary.setHidden(false);
            } else {
                plantsVsZombiesAnniversary.setHidden(true);
            }
        }
        
        //万圣节
        //日期 10月30日 ~ 11月2日
    }
})
