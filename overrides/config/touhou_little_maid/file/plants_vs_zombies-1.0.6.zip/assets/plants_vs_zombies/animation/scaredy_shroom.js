var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
        //胆小菇的动画，血量小于25%的时候躲起来
        
        var maxHealth = maid.getMaxHealth()
        var Health = maid.getHealth()
        var percentHealth = Health / maxHealth
        if (percentHealth <= 0.25) {
			GlWrapper.translate(0, 0.6, 0);
        }
    }
})