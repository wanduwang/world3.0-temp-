var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
	animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
		main = modelMap.get("main");
		bottom1 = modelMap.get("bottom_0");
		bottom2 = modelMap.get("bottom_1");

		if (main != undefined) {main.setOffsetY(Math.sin(ageInTicks * 0.08) * 0.03)}
		if (bottom1 != undefined) {bottom1.setRotateAngleX(Math.sin(ageInTicks * 0.16) * 0.1 + 0.5)}
		if (bottom2 != undefined) {bottom2.setRotateAngleX(Math.sin(ageInTicks * 0.16) * 0.1 + 0.5)}
	}
})