var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
        //大嘴花的动画
        //别的植物以后也会加上

        stem1 = modelMap.get("stem1");
        stem2 = modelMap.get("stem2");
        
        stem1.setRotateAngleX(-Math.cos(ageInTicks * 0.08) * 0.2 - 0.5);
        stem1.setRotateAngleZ(-Math.cos(ageInTicks * 0.03) * 0.08);
        stem2.setRotateAngleX(Math.cos(ageInTicks * 0.08) * 0.25 + 1);

    }
})