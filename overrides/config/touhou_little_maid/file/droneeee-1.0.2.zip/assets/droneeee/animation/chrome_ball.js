var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
	animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
		teacon = modelMap.get("teacon");
		sphere = modelMap.get("sphere");
		drone = modelMap.get("drone");
		main = modelMap.get("main");
		
		var d = new Date();
		rotate = ageInTicks % 360;

		if (drone != undefined) {drone.setOffsetY(Math.sin(ageInTicks * 0.08) * 0.03)}

		//1633665600000(2021-10-08 12:00)
		if(maid.isSitting()){
			if(d.getTime() < 1633665600000) {
				teacon.setHidden(false);
				if (teacon != undefined) {teacon.setOffsetY(Math.sin(ageInTicks * 0.16) * 0.05)}
				if (teacon != undefined) {teacon.setRotateAngleZ(Math.sin(ageInTicks * 0.2) * 0.04)}
				if (teacon != undefined) {teacon.setRotateAngleX(Math.sin(ageInTicks * 0.22) * 0.05)}
			}else{
				teacon.setHidden(true);
			}
		}else{
			teacon.setHidden(true);
		}

		if (limbSwingAmount > 0.001) {
			main.setRotateAngleZ(limbSwingAmount * 7.12);
		}

	}
})