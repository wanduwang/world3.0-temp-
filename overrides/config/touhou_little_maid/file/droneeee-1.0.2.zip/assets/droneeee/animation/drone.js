var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
	animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
		fan = modelMap.get("fan");
		fan2 = modelMap.get("fan2");
		fan3 = modelMap.get("fan3");
		fan4 = modelMap.get("fan4");
		drone = modelMap.get("drone");

		rotate = ageInTicks % 360;

		if (maid.isSitting()) {
			GlWrapper.translate(0, 1, 0)
		} else {
			GlWrapper.rotate(limbSwingAmount * 16, 1, 0, 0)
			if (drone != undefined) {drone.setOffsetY(Math.sin(ageInTicks * 0.08) * 0.03)}

			if (limbSwingAmount > 0.001) {
				if (fan != undefined) {fan.setRotateAngleY(rotate * 2)}
				if (fan2 != undefined) {fan2.setRotateAngleY(rotate)}
				if (fan3 != undefined) {fan3.setRotateAngleY(rotate)}
				if (fan4 != undefined) {fan4.setRotateAngleY(rotate * 2)}
			}else{
				if (fan != undefined) {fan.setRotateAngleY(rotate * 0.8)}
				if (fan2 != undefined) {fan2.setRotateAngleY(rotate)}
				if (fan3 != undefined) {fan3.setRotateAngleY(rotate)}
				if (fan4 != undefined) {fan4.setRotateAngleY(rotate)}
			}
		}
	}
})