var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
	animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
		teacon = modelMap.get("teacon");

		teacon.setHidden(false);
		if (teacon != undefined) {teacon.setOffsetY(Math.sin(ageInTicks * 0.16) * 0.05)}
		if (teacon != undefined) {teacon.setRotateAngleZ(Math.sin(ageInTicks * 0.2) * 0.04)}
		if (teacon != undefined) {teacon.setRotateAngleX(Math.sin(ageInTicks * 0.22) * 0.05)}
	}
})