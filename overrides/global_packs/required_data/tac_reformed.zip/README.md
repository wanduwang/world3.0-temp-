# E-Datapack for TaC
Example datapack for Timeless and classics
This datapack contains **unmodified** files from the original mod!

# To Install
Just stuff this .zip file right into your World's {datapacks} folder, either in your **world** folder for MC servers, or in your **saves** folder

Use /reload if loading a datapack into a currently running instance of your world.

Special thanks to @Autovw (https://github.com/Autovw), I (ClumsyAlien) was just a bit too lazy to build the structure for this datapack
